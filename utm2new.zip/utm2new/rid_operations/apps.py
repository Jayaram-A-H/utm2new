from django.apps import AppConfig


class DssOperationsConfig(AppConfig):
    name = "rid_operations"
