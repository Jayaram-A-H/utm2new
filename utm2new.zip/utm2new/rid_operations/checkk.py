import requests
payload={
  "extents": {
    "spatial_volume": {
      "footprint": {
        "vertices": [
          {"lng": 7.4753388728502985, "lat": 46.97478407188788}, {"lng": 7.4753388728502985, "lat": 46.97542602102813}, {"lng": 7.473543702146228, "lat": 46.97542602102813}, {"lng": 7.473543702146228, "lat": 46.97478407188788}
        ]
      },
      "altitude_lo": 0,
      "altitude_hi": 122
    },
    "time_start": "2024-07-08T18:49:38.842Z",
    "time_end":  "2024-07-08T19:49:38.842Z"
  },
  "callbacks": {
  	"identification_service_area_url": "https://192.168.10.114:8000/dss/identification_service_areas"
  }
}
headers= {'content-type': 'application/json', 'Authorization': 'Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOiJsb2NhbGhvc3QiLCJleHAiOjE3MjA0MjExMTksImlzcyI6ImxvY2FsaG9zdCIsInNjb3BlIjoiZHNzLnJlYWQuaWRlbnRpZmljYXRpb25fc2VydmljZV9hcmVhcyIsInN1YiI6ImNoZWNrX3NjZCJ9.RkBHwftGo4WEyCut5Jr2Hir-GqBaCM2VB5zb_i10AttfjCPYQpA9E9-w3w2QjVvBDEkpQA6LYUPgtec2lP9Q6KoFAZbLZrYvK9vms1f8cQpj7O94Q613d-sckpzNTM0sYRi6S-9lJBWFqqUO58DDazA2s75jiU_gF1-5aCOepNc'}
dss_subscription_url='http://172.18.0.12:8082/v1/dss/subscriptions/882f8160-449b-4660-b103-72017df0d80f'
dss_r = requests.put(dss_subscription_url, json=payload, headers=headers)
print(dss_r)

