from django.apps import AppConfig


class GeoFenceOperationsConfig(AppConfig):
    name = "geo_fence_operations"
