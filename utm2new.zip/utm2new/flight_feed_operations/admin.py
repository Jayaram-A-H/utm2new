from django.contrib import admin

from flight_feed_operations.models import SignedTelmetryPublicKey

admin.site.register(SignedTelmetryPublicKey)
# Register your models here.
