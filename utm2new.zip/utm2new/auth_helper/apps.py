from django.apps import AppConfig


class AuthHelperConfig(AppConfig):
    name = "auth_helper"
