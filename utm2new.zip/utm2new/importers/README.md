# Importers -> E2E Verification

The Importers directory has been moved to `openutm/verification` [here](https://github.com/openutm/verification).
