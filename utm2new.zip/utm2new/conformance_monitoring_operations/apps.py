from django.apps import AppConfig


class ConformanceMonitoringOperationsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "conformance_monitoring_operations"
