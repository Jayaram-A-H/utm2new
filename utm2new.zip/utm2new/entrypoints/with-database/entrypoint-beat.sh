#!/bin/bash

echo Waiting for DBs...
if ! wait-for-it --parallel --service redis:6379 --service db:5432; then
    exit
fi

celery --app=flight_blender beat --loglevel=info --scheduler django_celery_beat.schedulers:DatabaseScheduler
