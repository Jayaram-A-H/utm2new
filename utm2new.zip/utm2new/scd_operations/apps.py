from django.apps import AppConfig


class ScdOperationsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "scd_operations"
